  (int)(long)&((struct stringpool_t *)0)->stringpool_str15,
  (int)(long)&((struct stringpool_t *)0)->stringpool_str484,
